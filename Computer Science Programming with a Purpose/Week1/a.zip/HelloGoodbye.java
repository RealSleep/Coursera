public class HelloGoodbye {
	public static void main(String[] args) {
		String f = args[0];
		String s = args[1];
		System.out.printf("Hello %s and %s.\nGoodbye %s and %s.",f,s,s,f);
	}
}